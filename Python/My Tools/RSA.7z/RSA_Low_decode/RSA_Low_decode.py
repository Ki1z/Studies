# 低解密指数攻击
import  RSAwienerHacker
# n, e
n=0
e=0
######
d =  RSAwienerHacker.hack_RSA(e,n)
if d:
    print(d)
